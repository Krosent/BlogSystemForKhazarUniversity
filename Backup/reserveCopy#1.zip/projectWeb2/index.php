<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<head>
    
    
<!--     CSS:-->
        <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="css/site_css.css">
    
<!--    JS, jQuery:-->
        <script src="js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="js/site_script.js"></script>
    
<!--    FONTS INTEGRATION-->
        <link href="https://fonts.googleapis.com/css?family=Baloo" rel="stylesheet">
    
    
    <style>
        .navbar-nav li{
         
            margin-left: 20px;
        }
    </style>
    
    </head>
        
    
    
    <body>
<!--    HORIZONTAL NAVIGATION CODE:-->
   <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid fds">
        <div class="navbar-header"><a class="navbar-brand" href="#">NEWS</a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-menubuilder"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse navbar-menubuilder">
            <ul class="nav navbar-nav navbar-right">
                <li ><a href="/">Лига Чемпионов</a>
                </li>
                <li class="divider-vertical"></li>
                <li><a href="/products">Лига Европы</a>
                </li><li class="divider-vertical"></li>
                 <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Топ-5
                <span class="caret"></span></a>
                     <ul class="dropdown-menu">
                         <li><a href="#">Испания</a></li>
                         <li><a href="#">Германия</a></li>
                         <li><a href="#">Англия</a></li>
                         <li><a href="#">Италия</a></li>
                         <li><a href="#">Франция</a></li>
                     </ul>
                </li><li class="divider-vertical"></li>
                <li><a href="/about-us">Россия-2018</a>
                </li><li class="divider-vertical"></li>
                <li><a href="/contact">Трансферы</a>
                </li>
            </ul>
        </div>
    </div>
        </nav> 
<!--END-->

   
<!-- main-banner CODE -->
  <header class="intro-header" style="background-image: url('images/header-img.jpg')">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="site-heading">
                        <h1>Clean Blog</h1>
                        <hr class="small">
                        <span class="subheading">A Clean Blog Theme by Start Bootstrap</span>
                        <a  href=""><span class="glyphicon glyphicon-chevron-down glyphicon-bg-paratemers" /></a>
                    </div>
                </div>
            </div>
        </div>
    </header>
<!--END        -->
        
<!--    NEWS BLOCK AND RIGHT COLUMN BLOCK    -->
        
        <div class="container-fluid" style="margin-top: 10px;">
        <div class="container-fluid row">
            <div class="col-md-12">
            <legend class="text-center"> <h2>Latest News:</h2></legend>
            </div>
            <div class="col-md-8">
    <h1>Alice in Wonderland, part dos</h1>
    <p>'You ought to be ashamed of yourself for asking such a simple question,' added the Gryphon; and then they both sat silent and looked at poor Alice, who felt ready to sink into the earth. At last the Gryphon said to the Mock Turtle, 'Drive on, old fellow! Don't be all day about it!' and he went on in these words:
    'Yes, we went to school in the sea, though you mayn't believe it—'
    'I never said I didn't!' interrupted Alice.
    'You did,' said the Mock Turtle.</p>
    <div>
<span class="badge">Posted 2012-08-02 20:47:04</span><div class="pull-right"><span class="label label-default">alice</span> <span class="label label-primary">story</span> <span class="label label-success">blog</span> <span class="label label-info">personal</span> <span class="label label-warning">Warning</span>
<span class="label label-danger">Danger</span></div>         
     </div>
    <hr>
    <h1>Revolution has begun!</h1>
    <p>'I am bound to Tahiti for more men.'
        'Very good. Let me board you a moment—I come in peace.' With that he leaped from the canoe, swam to the boat; and climbing the gunwale, stood face to face with the captain.
        'Cross your arms, sir; throw back your head. Now, repeat after me. As soon as Steelkilt leaves me, I swear to beach this boat on yonder island, and remain there six days. If I do not, may lightning strike me!'A pretty scholar,' laughed the Lakeman. 'Adios, Senor!' and leaping into the sea, he swam back to his comrades.</p>
    <div>
        <span class="badge">Posted 2012-08-02 20:47:04</span><div class="pull-right"><span class="label label-default">alice</span> <span class="label label-primary">story</span> <span class="label label-success">blog</span> <span class="label label-info">personal</span> <span class="label label-warning">Warning</span>
<span class="label label-danger">Danger</span></div>
    </div>     
    <hr>
</div>
            <div class="col-md-4">
             <div class="well">
                    <h2>About Author</h2>
                    <img src="" class="img-rounded" />
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna</p>
                    <a href="#" class="btn btn-default">Read more</a>
                </div>
            </div>
            
            <div class="col-md-4">
<div class="panel panel-default">
<div class="panel-heading"> <span class="glyphicon glyphicon-list-alt"></span><b>  Latest 5 News</b></div>
<div class="panel-body">
<div class="row">
<div class="col-xs-12">
<ul id="demo3" style="height: auto;">
<li class="news-item">Curabitur porttitor ante eget hendrerit adipiscing. Maecenas at magna accumsan,
    									rhoncus neque id, fringilla dolor. <a href="#">Read more...</a></li>
<li class="news-item">Curabitur porttitor ante eget hendrerit adipiscing. Maecenas at magna accumsan,
										rhoncus neque id, fringilla dolor. <a href="#">Read more...</a></li>
<li class="news-item">Praesent ornare nisl lorem, ut condimentum lectus gravida ut. Ut velit nunc, vehicula
										volutpat laoreet vel, consequat eu mauris. <a href="#">Read more...</a></li>
<li class="news-item" style="display: none;">Nunc ultrices tortor eu massa placerat posuere. Vivamus viverra sagittis nunc. Nunc
										et imperdiet magna. Mauris sed eros nulla. <a href="#">Read more...</a></li>
<li class="news-item" style="display: none;">Morbi sodales tellus sit amet leo congue bibendum. Ut non mauris eu neque fermentum
										pharetra. <a href="#">Read more...</a></li>
<li class="news-item" style="display: none;">In pharetra suscipit orci sed viverra. Praesent at sollicitudin tortor, id sagittis
										magna. Fusce massa sem, bibendum id. <a href="#">Read more...</a> </li>
<li class="news-item" style="display: none;">Maecenas nec ligula sed est suscipit aliquet sed eget ipsum. Suspendisse id auctor
										nibh. Ut porttitor volutpat augue, non sodales odio dignissi id. <a href="#">Read more...</a></li>
<li class="news-item" style="display: none;">Onec bibendum consectetur diam, nec euismod urna venenatis eget. Cras consequat
										convallis leo. <a href="#">Read more...</a> </li>
</ul>
</div>
</div>
</div>
<div class="panel-footer"> </div>
</div>
</div>
            
            <div class="col-md-8" style="">
           <div class="container">
               <ul class="pagination">
              <li class="disabled"><a href="#">«</a></li>
              <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">4</a></li>
              <li><a href="#">5</a></li>
              <li><a href="#">»</a></li>
            </ul>
</div>
            
            </div>
            
            
            </div>
        
        </div>
        
<!--        END HERE:-->
</body>
    
    <footer>
    <div class="footer" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3> Contact </h3>
                    <ul>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h3> Important Links </h3>
                    <ul>
                        <li> <a href="#"> Admission </a> </li>
                        <li> <a href="#"> Academic </a> </li>
                        <li> <a href="#"> Career </a> </li>
                        <li> <a href="#"> Administration </a> </li>
                        <li> <a href="#"> Notice </a> </li>
                        <li> <a href="#"> Tender </a> </li>
                        <li> <a href="login.php"> Teacher Login </a> </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h3> Location </h3>
                    <ul>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                        <li> <a href="#"> Lorem Ipsum </a> </li>
                    </ul>
                </div>
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
    </div>
    <!--/.footer-->

    <div class="footer-bottom">
        <div class="container">
            <p class="pull-left"> Copyright © 2017, Aysel and Artyom. <br> All rights reserved.</p>
            <div class="pull-right">
                <ul class="nav nav-pills payments">
                    <li><i class="fa fa-cc-visa"></i></li>
                    <li><i class="fa fa-cc-mastercard"></i></li>
                    <li><i class="fa fa-cc-amex"></i></li>
                    <li><i class="fa fa-cc-paypal"></i></li>
                </ul>
            </div>
        </div>
    </div>
    <!--/.footer-bottom-->
</footer>
    
</html>
  
  
    
    
    
    
    





    
    
    
    
    